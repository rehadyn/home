<section id="intro" class="wrapper style1 fullscreen fade-up">
      <div class="inner">
        <h1>Reza Hadiwijaya Dynasti</h1>
        <p>Postgraduate Program Universitas Negeri Makassar</p>
        <li>IT Enthusiast</li>
        <li>Web Developer</li>
        <li>Teacher</li>
      </div>
    </section>