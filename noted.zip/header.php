<header id="header">
    <a href="index.html" class="title">Home</a>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="generic.php" class="active">Generic</a></li>
            <li><a href="elements.php">Elements</a></li>
        </ul>
    </nav>
</header>