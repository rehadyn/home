<section id="sidebar">
    <div class="inner">
      <nav>
        <ul>
          <li><a href="#intro">Welcome</a></li>
          <li><a href="#one">About me</a></li>
          <li><a href="#two">Aerial Photograph</a></li>
          <li><a href="#three">Contact</a></li>
        </ul>
      </nav>
    </div>
  </section>